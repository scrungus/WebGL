HOW TO USE:

f - face rendering mode
e - edge rendering mode 
v - vertex rendering mode

arrow keys - translate camera 
scroll wheel - zoom in/out
click-and-drag - arcball camera mode